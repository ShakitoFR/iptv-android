package fr.shakito.iptv;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * « IPTV Maison » : l'appli TV du relais IPTV de Home Assistant (la même que le module TizenBrew du salon)
 * en plein écran sur la Chromecast. Aucun secret ici : Home Assistant ne répond à l'adresse d'entrée
 * que pour l'IP de la Chromecast, puis redirige vers l'appli.
 */
public class MainActivity extends Activity {
    static final String HA = "http://192.168.1.201:8123";
    static final String START = HA + "/api/iptv_relay/tv";

    private WebView web;
    private boolean appli = false; // l'appli est chargée (sinon : page d'erreur, Retour ferme)

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);      // la page passe en width=1920 → mise à l'échelle de l'écran
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        web.addJavascriptInterface(new Pont(), "AppAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                appli = url != null && url.startsWith(HA);
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) erreur("Home Assistant injoignable (" + e.getDescription() + ")");
            }

            @Override
            public void onReceivedHttpError(WebView v, WebResourceRequest r, WebResourceResponse e) {
                if (!r.isForMainFrame()) return;
                erreur(e.getStatusCode() == 404
                        ? "Home Assistant refuse l'accès : l'adresse IP de cet appareil n'est pas autorisée."
                        : "Erreur " + e.getStatusCode() + " de Home Assistant");
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public Bitmap getDefaultVideoPoster() { // pas d'icône « lecture » grise avant la vidéo
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }
        });
        setContentView(web);
        web.loadUrl(START);
    }

    private void erreur(String message) {
        appli = false;
        String html = "<html><body style='background:#0d1117;color:#fff;font-family:sans-serif;display:flex;"
                + "align-items:center;justify-content:center;height:100vh;margin:0;text-align:center'><div>"
                + "<h1>📺 IPTV Maison</h1><p style='font-size:22px'>" + message + "</p>"
                + "<p style='color:#8b949e'>Nouvel essai dans 10 s · Retour pour quitter</p></div>"
                + "<script>setTimeout(function(){location.href='" + START + "'},10000)</script></body></html>";
        web.post(() -> web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null));
    }

    /** Touches Android → codes de la télécommande Samsung, que l'appli connaît déjà. 0 = laisser passer. */
    private static int tizen(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_BACK: return 10009;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: return 10252;
            case KeyEvent.KEYCODE_MEDIA_PLAY: return 415;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: return 19;
            case KeyEvent.KEYCODE_MEDIA_STOP: return 413;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: return 417;
            case KeyEvent.KEYCODE_MEDIA_REWIND: return 412;
            case KeyEvent.KEYCODE_CHANNEL_UP: return 427;
            case KeyEvent.KEYCODE_CHANNEL_DOWN: return 428;
            case KeyEvent.KEYCODE_PROG_RED: return 403;
            case KeyEvent.KEYCODE_PROG_GREEN: return 404;
            case KeyEvent.KEYCODE_PROG_YELLOW: return 405;
            case KeyEvent.KEYCODE_PROG_BLUE: return 406;
            case KeyEvent.KEYCODE_GUIDE: return 404;
            case KeyEvent.KEYCODE_INFO: return 457;
            default: return 0;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = tizen(e.getKeyCode());
        if (code == 0) return super.dispatchKeyEvent(e); // flèches, OK, chiffres : gérés par la WebView
        if (!appli) {
            if (e.getKeyCode() == KeyEvent.KEYCODE_BACK && e.getAction() == KeyEvent.ACTION_UP) finish();
            return true;
        }
        if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            web.evaluateJavascript("(function(c){var t=document.activeElement||document.body||document;"
                    + "var e=document.createEvent('Event');e.initEvent('keydown',true,true);e.keyCode=c;e.which=c;"
                    + "t.dispatchEvent(e);})(" + code + ")", null);
        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    protected void onStop() {
        // Accueil ou veille : on quitte (la page enregistre la position du film en partant) ;
        // au prochain lancement, l'appli repart de l'accueil et relève un éventuel ordre du dashboard.
        super.onStop();
        if (!isFinishing()) {
            web.loadUrl("about:blank");
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /** Pont JavaScript : window.AppAndroid (fermeture depuis le menu « Quitter » de l'appli). */
    class Pont {
        @JavascriptInterface
        public void quitter() {
            runOnUiThread(() -> {
                web.loadUrl("about:blank");
                finishAndRemoveTask();
            });
        }
    }
}
